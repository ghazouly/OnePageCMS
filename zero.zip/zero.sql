-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2015 at 03:38 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zero`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(70) NOT NULL,
  `password` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'ahmed', '9193ce3b31332b03f7d8af056c692b84');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE IF NOT EXISTS `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `en_title` varchar(255) NOT NULL,
  `en_sub_title` varchar(500) NOT NULL,
  `ar_title` varchar(255) NOT NULL,
  `ar_sub_title` varchar(500) NOT NULL,
  `img` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `en_title`, `en_sub_title`, `ar_title`, `ar_sub_title`, `img`) VALUES
(1, 'magued ', 'magued magued magued magued magued magued magued magued magued magued magued magued magued magued magued magued magued magued magued magued magued magued ', '', '', '5OqeN1WxcOfl.jpg'),
(25, 'WE ROCK!  ', 'WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  WE ROCK!  ', '', '', 'SSI7Wt9PZiWW.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `ppl`
--

CREATE TABLE IF NOT EXISTS `ppl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` text NOT NULL,
  `ar_content` text NOT NULL,
  `en_content` text NOT NULL,
  `ar_name` varchar(500) NOT NULL,
  `en_name` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `ppl`
--

INSERT INTO `ppl` (`id`, `img`, `ar_content`, `en_content`, `ar_name`, `en_name`) VALUES
(7, 'XumP95P28kK8.jpg', '', 'System Administrator   System Administrator   System Administrator   System Administrator   System Administrator   System Administrator   ', '', 'Chan'),
(8, 'rNnIz4I5ekZr.jpg', '', 'Web developer  System Administrator   System Administrator   System Administrator   System Administrator   System Administrator   System Administrator   System Administrator   System Administrator   System Administrator   System Administrator   System Administrator   System Administrator   System Administrator   System Administrator   ', '', 'Peter');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ar_title` varchar(255) NOT NULL,
  `en_title` varchar(255) NOT NULL,
  `ar_content` text NOT NULL,
  `en_content` text NOT NULL,
  `icon` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `ar_title`, `en_title`, `ar_content`, `en_content`, `icon`) VALUES
(4, 'Happy Client', 'Happy Client', 'Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.', 'Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.', 'fa fa-envelope'),
(5, 'Happy Client', 'Happy Client', 'Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.', 'Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.', 'fa fa-envelope'),
(6, 'Happy Client', 'Happy Client', 'Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.', 'Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.', 'fa fa-envelope'),
(7, 'Happy Client', 'Happy Client', 'Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.', 'Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.', 'fa fa-envelope'),
(8, 'Happy Client', 'Happy Client', 'Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.', 'Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.', 'fa fa-envelope'),
(9, 'Happy Client', 'Happy Client', 'Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.', 'Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.', 'fa fa-envelope');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE IF NOT EXISTS `skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ar_name` varchar(150) NOT NULL,
  `en_name` varchar(150) NOT NULL,
  `per` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `ar_name`, `en_name`, `per`) VALUES
(2, 'arabicccc', 'englishhhhh', 7),
(3, 'Branding', 'Branding', 8),
(4, 'Branding', 'Branding', 4),
(5, 'Branding', 'Branding', 9),
(6, 'Branding', 'Branding', 3),
(7, 'Branding', 'Branding', 7),
(8, 'Branding', 'Branding', 7);

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE IF NOT EXISTS `slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `en_title` varchar(255) NOT NULL,
  `en_sub_title` varchar(500) NOT NULL,
  `ar_title` varchar(255) NOT NULL,
  `ar_sub_title` varchar(500) NOT NULL,
  `img` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `en_title`, `en_sub_title`, `ar_title`, `ar_sub_title`, `img`) VALUES
(21, 'first slide title', 'first slide titlefirst slide titlefirst slide titlefirst slide titlefirst slide titlefirst slide titlefirst slide titlefirst slide titlefirst slide title', '', '', 'hcGuXVnqJ3ZE.jpg'),
(22, 'second slide title', 'second slide titlesecond slide titlesecond slide titlesecond slide titlesecond slide titlesecond slide titlesecond slide titlesecond slide titlesecond slide title', '', '', '7GKY3qmL1m3R.jpg'),
(23, 'third slide title', 'third slide titlethird slide titlethird slide titlethird slide titlethird slide titlethird slide title', '', '', 'rUWw5zBHc6im.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `works`
--

CREATE TABLE IF NOT EXISTS `works` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` text NOT NULL,
  `ar_title` varchar(500) NOT NULL,
  `en_title` varchar(500) NOT NULL,
  `en_content` text NOT NULL,
  `ar_content` text NOT NULL,
  `link` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `works`
--

INSERT INTO `works` (`id`, `img`, `ar_title`, `en_title`, `en_content`, `ar_content`, `link`) VALUES
(2, '../solution/Wvz1TjIwWZj3.jpg', '', 'My project  ', 'My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  My project  ', '', 'http://www.exmaple.com'),
(3, '../solution/bKezdhMz7QO0.jpg', '', 'My App  ', 'My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  My App  ', '', 'http://www.exmaple.com');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
