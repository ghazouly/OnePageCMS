<?php
class Dbconfig {
    protected $serverName;
    protected $userName;
    protected $passCode;
    protected $dbName;

    function Dbconfig() {
        
        $this -> serverName = 'localhost';
        $this -> userName = 'root';
        $this -> passCode = 'root';
        $this -> dbName = 'zero';
        /*
        $this -> serverName = 'ns8171.hostgator.com';
    	$this -> userName = 'sherif4_hoor';
    	$this -> passCode = 'C?i%Gy7?Ev&7';
    	$this -> dbName = 'sherif4_zero';
        */


    }
}
?>