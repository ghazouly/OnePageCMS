<?php
session_start();

include_once 'config/Dbconfig.php';
include_once 'php_library/Mysql.php';



if (isset($_POST['submit']) && !empty($_POST['per'])  && !empty($_POST['ar_name'])  && !empty($_POST['en_name']) ) 
{
	

	$conn = new Mysql();
	$conn -> dbConnect();

	$ar_name = $_POST['ar_name'];
	$ar_name = stripcslashes($ar_name);
	$ar_name = mysql_real_escape_string($ar_name);

	$en_name = $_POST['en_name'];
	$en_name = stripslashes($en_name);
	$en_name = mysql_real_escape_string($en_name);

	$per = $_POST['per'];
	$per = stripslashes($per);
	$per = mysql_real_escape_string($per);
	
	$form_data = array(
				 
				'ar_name' => $ar_name,
				'en_name' => $en_name,
				'per' => $per,
				);
		$result=$conn->dbRowInsert('skills', $form_data);
		$conn->dbDisconnect();
	
	
	if($result){
			header("location:skills.php?msg=successins");
		}
		else
		{
			
			header("location:skills.php?msg=failins");
		}
}
else 
{
	header("location:addskil.php?msg=empty");
}
?>