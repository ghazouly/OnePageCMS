<?php
session_start();
include_once 'config/Dbconfig.php';
include ('php_library/Mysql.php');



if (isset($_POST['submit'])) {

	$conn = new Mysql();
	$conn -> dbConnect();
	$id = $_GET['id'];
	$ar_title = $_POST['ar_title'];
	$ar_title = stripcslashes($ar_title);
	$ar_title = mysql_real_escape_string($ar_title);
	$en_title = $_POST['en_title'];
	$en_title = stripcslashes($en_title);
	$en_title = mysql_real_escape_string($en_title);
	$ar_content = $_POST['ar_content'];
	$ar_content = stripcslashes($ar_content);
	$ar_content = mysql_real_escape_string($ar_content);
	$en_content = $_POST['en_content'];
	$en_content = stripslashes($en_content);
	$en_content = mysql_real_escape_string($en_content);
	$icon = $_POST['icon'];
	$icon = stripslashes($icon);
	$icon = mysql_real_escape_string($icon);
	
	
	$form_data = array(

		'ar_title' => $ar_title,
		'en_title' => $en_title,
		'en_content' => $en_content,
		'ar_content' => $ar_content,
		'icon' => $icon,
		);
	$where = "WHERE id=$id";

	$result = $conn -> dbRowUpdate('services', $form_data, $where);

	$conn -> dbDisconnect();

	if ($result) {
		header("location:services.php?msg=successup");
	} else {

		header("location:services.php?msg=failiup");
	}

} else {
	header("location:services.php");
}
?>