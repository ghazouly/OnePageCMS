<?php 
include 'header.php';
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Slider</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">

       <div class="panel panel-default">
        <div class="panel-heading">
            Add New Slide
        </div>
        <div class="panel-body">

            <div class="row">
                <form action="insertslide.php" method="post" enctype="multipart/form-data"  >
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>choose image</label>
                            <input type="file" name="file">
                        </div>
                        <div class="col-md-12">
                            <div class="col-md-6">
                                <h2>Text on slide</h2>
                                <div class="form-group">
                                    <label>title</label>
                                    <input class="form-control" placeholder="Enter text" name="en_title">
                                </div>
                                <div class="form-group">
                                    <label>sub title</label>
                                    <input class="form-control" placeholder="Enter text" name="en_sub_title">
                                </div>
                                <input type="submit" class="btn btn-primary " value="Add slide" name="submit">
                            </div>
                        </div>

                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<!-- /.row -->
</div>
<!-- /#page-wrapper -->
<?php 

include 'footer.php';

?>
