<?php 
include 'header.php';
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Add Clients</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    <?php 

    if(isset($_GET['msg']))
    {

        if($_GET['msg'] == 'empty') { echo '<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        please enter all required data , so you can add 
        </div>' ; }



    }
     ?>
    <div class="row">

       <div class="panel panel-default">
        <div class="panel-heading">
            Add New Client
        </div>
        <div class="panel-body">

            <div class="row">
                <form action="insertre.php" method="post" enctype="multipart/form-data"  >
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>choose image</label>
                            <input type="file" name="file">
                        </div>
                                

                                <div class="form-group">
                                    <label>Name</label>
                                    <input class="form-control" placeholder="Enter text" name="en_name">
                                </div>
                                <div class="form-group">
                                    <label>Skills</label>
                                    <textarea class="form-control" placeholder="Enter text" name="en_content" cols="30" rows="10"></textarea>
                                </div>

                            <input type="submit" class="btn btn-primary " value="Add Client" name="submit">
                                
                        </div>

                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<!-- /.row -->
</div>
<!-- /#page-wrapper -->
<?php 

include 'footer.php';

?>
