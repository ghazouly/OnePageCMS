<?php 
include 'header.php';


?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Services</h1>
        </div>
        <!-- /.col-lg-12 -->


    </div>

    <?php




    if(isset($_GET['msg']))
    {

        if($_GET['msg'] == 'successup') { echo '<div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        data was updated successfully !
        </div>' ; }


        if($_GET['msg'] == 'failup') { echo '<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        please try again
        </div>' ; }

        if($_GET['msg'] == 'successins') { echo '<div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        data was added successfully !
        </div>' ; }


        if($_GET['msg'] == 'failins') { echo '<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        try to add again please , as there was some error
        </div>' ; }

           if($_GET['msg'] == 'empty') { echo '<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        please enter all data !
        </div>' ; }


        if($_GET['msg'] == 'successde') { echo '<div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        data was deleted successfully !</a>.
        </div>' ; }


        if($_GET['msg'] == 'failde') { echo '<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        try to delete again please  , errors happend  
        </div>' ; }

    }

    include_once 'config/Dbconfig.php';
    include_once 'php_library/Mysql.php';




    $conn = new Mysql();

    $conn -> dbConnect();
    $slides = $conn -> selectAll('services');
    $i = 1; 



    ?>
    
    <!-- /.row -->
    <div class="row">
        <div class="col-lg-11">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Show all Services
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>English Title</th>
                                    <th>English content</th>
                                    <th>Edit </th>
                                    <th>Delete </th>
                                </tr>
                            </thead>
                            <tbody>
    <?php 
    while ($slide = mysql_fetch_assoc($slides)) {
        $i++;
 extract($slide);
        echo '
                                <tr>
                                    <td>'.$i.'</td>
                                    <td>'.$en_title.'</td>
                                    <td>'.$en_content.'</td>                                  
                                    <td>
                                        <a href="editservice.php?id='.$id.'" class="btn btn-warning btn-circle"><i class="fa fa-pencil-square-o"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <a  href="deleteservice.php?id='.$id.'" class="btn btn-danger btn-circle "><i class="fa fa-times"></i>
                                        </a>
                                    </td>
                                </tr>';
    }

     ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.table-responsive -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
    </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->
<?php 

include 'footer.php';

?>