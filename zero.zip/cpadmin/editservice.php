<?php 
include 'header.php';



include_once 'config/Dbconfig.php';
include_once('php_library/Mysql.php');
$conn = new Mysql();

$conn -> dbConnect();
$res = $conn -> selectWhere('services', 'id', '=', $_GET['id'], 'int');

$service= mysql_fetch_array($res);

extract($service);

$conn->dbDisconnect();

?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Services</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">

     <div class="panel panel-default">
        <div class="panel-heading">
            Edit Service
        </div>
        <div class="panel-body">
            <div class="row">
                <form action="insertservice.php" method="post"   >
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>enter icon</label>
                            <input class="form-control" placeholder="Enter text" name="icon" 
                            value="<?php echo $icon; ?>">
                        </div>
                        <div class="col-md-12">
                            <div class="col-md-6">
                                <h2>Arabic content</h2>
                                <div class="form-group">
                                    <label>service title</label>
                                    <input class="form-control" placeholder="Enter text" name="ar_title"
                                     value="<?php  echo $ar_title; ?>">
                                </div>
                                <div class="form-group">
                                    <label>service content</label>
                                    <textarea class="form-control" placeholder="Enter text" name="ar_content"
                                     name="ar_content"  cols="30" rows="10"><?php  echo $ar_content; ?></textarea>
                                    
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h2>English content</h2>
                                <div class="form-group">
                                    <label>service title</label>
                                    <input class="form-control" placeholder="Enter text" name="en_title" value="<?php  echo $en_title; ?>" >
                                </div>
                                <div class="form-group">
                                    <label>service content</label>
                                    <textarea class="form-control" placeholder="Enter text" name="en_content" 
                                    name="en_content" cols="30" rows="10"> <?php  echo $en_content; ?></textarea>
                                    
                                </div>
                            </div>
                            <input type="submit" class="btn btn-primary " value="Updated service" name="submit">
                        </div>

                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<!-- /.row -->
</div>
<!-- /#page-wrapper -->
<?php 

include 'footer.php';

?>
