<?php 
include 'header.php';


include_once 'config/Dbconfig.php';
include_once('php_library/Mysql.php');
$conn = new Mysql();

$conn -> dbConnect();
$row = $conn -> selectWhere('skills', 'id', '=', $_GET['id'], 'int');

$skil= mysql_fetch_array($row);

extract($skil);

$conn->dbDisconnect();
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Skills</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
     <div class="panel panel-default">
        <div class="panel-heading">
            Edit New Skil
        </div>
        <div class="panel-body">
            <div class="row">
                <form action="updateskil.php?id=<?php echo $_GET['id'];  ?>" method="post"   >
                    <div class="col-md-12">
                     <div class="form-group">
                        <label>Skil percentage</label>
                        <select name="per" class="form-control">
                            <?php echo "<option>$per</option>";  ?>
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                            <option>6</option>
                            <option>7</option>
                            <option>8</option>
                            <option>9</option>
                            <option>10</option>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <div class="col-md-6">
                            <h2>Arabic content</h2>
                            <div class="form-group">
                                <label>Skil name</label>
                                <input class="form-control" placeholder="Enter text" name="ar_name" value="<?php echo $ar_name; ?>">
                            </div>
                          
                        </div>
                        <div class="col-md-6">
                            <h2>English content</h2>
                            <div class="form-group">
                                <label>Skil name</label>
                                <input class="form-control" placeholder="Enter text" value="<?php echo $en_name; ?>" name="en_name">
                            </div>
                     
                        </div>
                        <input type="submit" class="btn btn-primary " value="update Skil" name="submit">
                    </div>

                </div>

            </form>
        </div>
    </div>
</div>
</div>
<!-- /.row -->
</div>
<!-- /#page-wrapper -->
<?php 

include 'footer.php';

?>
