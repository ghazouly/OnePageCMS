<?php 
include 'header.php';



include_once 'config/Dbconfig.php';
include_once('php_library/Mysql.php');
$conn = new Mysql();

$conn -> dbConnect();
$row = $conn -> selectWhere('slider', 'id', '=', $_GET['id'], 'int');

$slide= mysql_fetch_array($row);

extract($slide);

$conn->dbDisconnect();
?>






<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Slider</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">

     <div class="panel panel-default">
        <div class="panel-heading">
            Add New Slide
        </div>
        <div class="panel-body">
            <div class="row">
                <form action="updateslide.php?id=<?php echo $_GET['id'] ; ?>" method="post" enctype="multipart/form-data" >
                    <div class="col-md-12">
                        <h2>Current image is :</h2>
                    <img src="<?php  echo $img;  ?>" class="img-responsive img-thumbnail" alt="">
 
                        <div class="form-group">
                            <label>choose another image</label>
                            <input type="file" name="file">
                        </div>
                        <div class="col-md-12">

                            <div class="col-md-6">
                                <h2>Arabic content</h2>
                                <div class="form-group">
                                    <label>title</label>
                                    <input class="form-control" placeholder="Enter text" name="ar_title" value="<?php  echo $ar_title;  ?>">
                                </div>
                                <div class="form-group">
                                    <label>sub title</label>
                                    <input class="form-control" placeholder="Enter text" name="ar_sub_title" value="<?php  echo $ar_sub_title;  ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h2>English content</h2>
                                <div class="form-group">
                                    <label>title</label>
                                    <input class="form-control" placeholder="Enter text" name="en_title" value="<?php  echo $en_title;  ?>">
                                </div>
                                <div class="form-group">
                                    <label>sub title</label>
                                    <input class="form-control" placeholder="Enter text" name="en_sub_title" value="<?php  echo $en_sub_title;  ?>">
                                </div>
                            </div>
                                

                            <input type="submit" class="btn btn-primary " value="Update Slide" name="submit">


                        </div>

                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<!-- /.row -->
</div>
<!-- /#page-wrapper -->
<?php 

include 'footer.php';

?>