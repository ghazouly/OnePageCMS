<?php 
include 'header.php';
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Solutions</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>

    <?php 

    if(isset($_GET['msg']))
    {


        if($_GET['msg'] == 'empty') { echo '<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        please enter all fields data
        </div>' ; }




    } ?>
    <!-- /.row -->
    <div class="row">

     <div class="panel panel-default">
        <div class="panel-heading">
            Add New Sample
        </div>
        <div class="panel-body">

            <div class="row">
                <form action="insertwork.php" method="post" enctype="multipart/form-data"  >
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>choose image</label>
                            <input type="file" name="file">
                        </div>
                        <label>link (optional)</label>
                        <div class="form-group input-group">

                            <span class="input-group-addon"><i class="fa fa-link"></i></span>
                            <input type="text" name="link" class="form-control" placeholder="Username">
                        </div>
                        <p class="form-control-static"><h4> example: http://www.exmaple.com</h4></p>
                        <div class="col-md-12">
                            
                                <h2>Add Content</h2>
                                <div class="form-group">
                                    <label>title</label>
                                    <input class="form-control" placeholder="Enter text" name="en_title">
                                </div>
                                <div class="form-group">
                                    <label>content</label>
                                    <textarea class="form-control" placeholder="Enter text" name="en_content" cols="30" rows="10"></textarea>
                                </div>
                            <input type="submit" class="btn btn-primary " value="Add solution" name="submit">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /.row -->
</div>
<!-- /#page-wrapper -->
<?php 

include 'footer.php';

?>
