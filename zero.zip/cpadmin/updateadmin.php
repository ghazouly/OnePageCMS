<?php
session_start();
include_once 'config/Dbconfig.php';
include ('php_library/Mysql.php');




// var_dump($_POST); die;

if (isset($_POST['submit']) && !empty($_POST['username']) && !empty($_POST['password']) && !empty($_POST['old_password']) && !empty($_POST['password_again'])) {

	$conn = new Mysql();
	$conn -> dbConnect();
	$username = $_POST['username'];
	$username = stripcslashes($username);
	$username = mysql_real_escape_string($username);
	$password = $_POST['password'];
	$password = stripcslashes($password);
	$password = mysql_real_escape_string($password);
	$old_password = $_POST['old_password'];
	$old_password = stripcslashes($old_password);
	$old_password = mysql_real_escape_string($old_password);
	$password_again = $_POST['password_again'];
	$password_again = stripslashes($password_again);
	$password_again = mysql_real_escape_string($password_again);
	$id = $_SESSION['admin_id'];
	$sql = "SELECT password , username FROM admins WHERE id='$id'";
	$res = mysql_query($sql);
	$row = mysql_fetch_assoc($res);

	// var_dump($row); die;

	if($row['password'] !== md5($old_password)) {
		header('location:editadmin.php?msg=wop');
		die;
	}

	if($password !== $password_again) {
		// new don't match
		header('location:editadmin.php?msg=ndm');
		die;
	}

$password = md5($password);

	
	
	$form_data = array(

		'username' => $username,
		'password' => $password,
		
		);
	$where = "WHERE id=1";

	$result = $conn -> dbRowUpdate('admins', $form_data, $where);

	$conn -> dbDisconnect();

	if ($result) {
		$_SESSION['username'] = $row['username'];
		header("location:editadmin.php?msg=successup");
	} else {

		header("location:editadmin.php?msg=failiup");
	}

} else {
	header("location:editadmin.php?empty");
}
?>