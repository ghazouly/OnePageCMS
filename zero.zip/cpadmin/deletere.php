<?php 
session_start();
include_once 'config/Dbconfig.php';
include('php_library/Mysql.php');
$conn=new Mysql();
if($_GET['id']){
        if(isset($_GET['img']) && file_exists($_GET['img'])){
        unlink($_GET['img']);
        }
        $conn->dbConnect();
        $where="WHERE id=".$_GET['id'];
        $result=$conn -> dbRowDelete('ppl', $where);
        $conn->dbDisconnect();
        if($result)
        {
            $msg='successde';
        }
        else
        {
            $msg='failde';
            
        }
        header("location:clients.php?msg=".$msg."");
    
}else{
    $msg='fail';
    header("location:clients.php?msg=".$msg."");
    header("content-type: text/html");
}
?>