<?php 
include 'header.php';
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Services</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">

     <div class="panel panel-default">
        <div class="panel-heading">
            Add New Service
        </div>
        <div class="panel-body">
            <div class="row">
                <form action="insertservice.php" method="post"   >
                    <div class="col-md-12">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>service title</label>
                                <input class="form-control" placeholder="Enter text" name="en_title">
                            </div>
                            <div class="form-group">
                                <label>service content</label>
                                <textarea class="form-control" placeholder="Enter text" name="en_content" 
                                name="en_content" cols="30" rows="10"></textarea>
                            </div>
                            <input type="submit" class="btn btn-primary " value="Add service" name="submit">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /.row -->
</div>
<!-- /#page-wrapper -->
<?php 

include 'footer.php';

?>
