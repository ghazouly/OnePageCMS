<?php 


include_once 'config/Dbconfig.php';
include_once('php_library/Mysql.php');
$conn = new Mysql();
$conn -> dbConnect();
$res = $conn -> selectAll('info');
$info = mysql_fetch_array($res);
extract($info);
$conn->dbDisconnect();
?>
<?php 
include 'header.php';
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">About</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">

       <div class="panel panel-default">
        <div class="panel-heading">
            Edit site info:
        </div>
        <div class="panel-body">

            <div class="row">
                <form action="updateinfo.php" method="post" enctype="multipart/form-data"  >
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>choose image</label>
                            <input type="file" name="file">
                        </div>
                        <div class="col-md-12">
                            <div class="col-md-6">
                                <h2>Slogan</h2>
                                <div class="form-group">
                                    <label>title</label>
                                    <input class="form-control" placeholder="Enter text" name="en_title">
                                </div>
                                <div class="form-group">
                                    <label>Details</label>
                                    <input class="form-control" placeholder="Enter text" name="en_sub_title">
                                </div>
                                <input type="submit" class="btn btn-primary " value="Updata your info" name="submit">
                            </div>
                        </div>

                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<!-- /.row -->
</div>
<!-- /#page-wrapper -->
<?php 

include 'footer.php';

?>
