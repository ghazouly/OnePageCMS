<?php
session_start();
include_once 'config/Dbconfig.php';
include ('php_library/Mysql.php');
include_once 'php_library/SimpleImage.php';
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


if (isset($_POST['submit'])) {

	$conn = new Mysql();
	$conn -> dbConnect();
		$ar_title = $_POST['ar_title'];
	$ar_title = stripcslashes($ar_title);
	$ar_title = mysql_real_escape_string($ar_title);

	$en_title = $_POST['en_title'];
	$en_title = stripslashes($en_title);
	$en_title = mysql_real_escape_string($en_title);

	$ar_content = $_POST['ar_content'];
	$ar_content = stripcslashes($ar_content);
	$ar_content = mysql_real_escape_string($ar_content);

	$en_content = $_POST['en_content'];
	$en_content = stripslashes($en_content);
	$en_content = mysql_real_escape_string($en_content);


	$link = $_POST['link'];
	$link = stripslashes($link);
	$link = mysql_real_escape_string($link);

	$image = $_FILES['file']['name'];
	$ex = explode('.', $image);
	$ex = end($ex);
	$new_name = generateRandomString(12) . '.' .$ex;
	$image = $_FILES['file']['name'];
	$row = $conn -> selectWhere('works', 'id', '=', $_GET['id'], 'int');
	$slide = mysql_fetch_array($row);

	if ($image) {
		if (file_exists($slide['img'])) {unlink($slide['img']);
		}

	}

	$folder = "../uploaded/";
	// image checking if exist or the input field is not empty
	if ($image) {
		// creating a filename
		$filename = $folder . $image;

		// uploading image file to specified folder
		$copied = copy($_FILES['file']['tmp_name'], $filename);
		$img = new SimpleImage();
		$img -> load($filename);
		$img -> resize(1350, 900);
		if (file_exists($filename)) {
			unlink($filename) or die("Failed to delete the image");
		}
		$img -> save($filename);
	}

	if ($image) {
		$form_data['img'] = $filename;
	}

	
	
	$form_data = array(
				 
				'ar_title' => $ar_title,
				'en_title' => $en_title,
					'link' => $link,
				'ar_content' => $ar_content,
				'en_content' => $en_content,
				'img' => $filename
				);
	$where = "WHERE id= '$slide[0]'";

	$result = $conn -> dbRowUpdate('works', $form_data, $where);

	$conn -> dbDisconnect();

	if ($result) {
		header("location:works.php?msg=successup");
	} else {

		header("location:works.php?msg=failiup");
	}

} else {
	header("location:works.php");
}
?>