<?php
$extension = strtolower(pathinfo($_FILES['icon']['name'],PATHINFO_EXTENSION));
$name = md5($_FILES['icon']['name'].time());
$fullName = $name.'.'.$extension;


switch ($_FILES['icon']['type']) {
	case "image/png":
		$img=imagecreatefrompng($_FILES['icon']['tmp_name']);
		break;
	default:
		$error = "Invalid Photo.' only png images'";die;
		break;
}

$crruentWidth=imagesx($img);
$crruentHeight=imagesy($img);

$newWidth=320;
$newHeight=160;

$scaledImage=imagecreatetruecolor($newWidth, $newHeight);

imagealphablending($img, true);
imagealphablending($scaledImage, false);
imagesavealpha($scaledImage, true);

imagecopyresampled($scaledImage, $img, 0, 0, 0, 0, $newWidth, $newHeight, $crruentWidth, $crruentHeight);


imagepng($scaledImage,$folder.$fullName);

imagedestroy($img);
imagedestroy($scaledImage);
?>