<?php 
include 'header.php';
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Skills</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <?php 

    if(isset($_GET['msg']))
    {

       



        if($_GET['msg'] == 'empty') { echo '<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        please enter all data   
        </div>' ; }

    } ?>
    <!-- /.row -->
    <div class="row">

     <div class="panel panel-default">
        <div class="panel-heading">
            Add New Skil
        </div>
        <div class="panel-body">

            <div class="row">
                <form action="insertskil.php" method="post" enctype="multipart/form-data"  >
                    <div class="col-md-12">
                     <div class="form-group">
                        <label>Skil percentage</label>
                        <select name="per" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                            <option>6</option>
                            <option>7</option>
                            <option>8</option>
                            <option>9</option>
                            <option>10</option>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <div class="col-md-6">
                            <h2>Arabic content</h2>
                            <div class="form-group">
                                <label>Skil name</label>
                                <input class="form-control" placeholder="Enter text" name="ar_name">
                            </div>
                          
                        </div>
                        <div class="col-md-6">
                            <h2>English content</h2>
                            <div class="form-group">
                                <label>Skil name</label>
                                <input class="form-control" placeholder="Enter text" name="en_name">
                            </div>
                     
                        </div>
                        <input type="submit" class="btn btn-primary " value="Add Skil" name="submit">
                    </div>

                </div>

            </form>
        </div>
    </div>
</div>
</div>
<!-- /.row -->
</div>
<!-- /#page-wrapper -->
<?php 

include 'footer.php';

?>
