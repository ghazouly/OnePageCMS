<?php session_start();
include 'config/Dbconfig.php';
include('php_library/Mysql.php');
$msg='';
if(isset($_POST['submit']) && !empty($_POST['username']) && !empty($_POST['password']) 	){
	$conn = new Mysql();
	$conn->dbConnect();
	$username=$_POST['username'];
	$password=$_POST['password']; 
	$username = stripslashes($username);
	$password = stripslashes($password);
	$username = mysql_real_escape_string($username);
	$password = mysql_real_escape_string($password);
	$password = md5($password);
	$sql="SELECT * FROM admins WHERE  username='$username' and password='$password'";
	$result=mysql_query($sql);
	$conn->dbDisconnect();
	$user= mysql_fetch_array($result);
	$count=mysql_num_rows($result);
	if($count===1){
		$_SESSION['username'] = $user['username'] ;
		$_SESSION['logged_in'] = true;
		$_SESSION['admin_id'] = $user['id'] ;
		header("location:index.php");
		die;
	}
	else
	{
		$msg = "fail";
		header("location:login.php?error=".$msg);
		die;
	}
}
else 
{
	$msg = "allneed";
	header("location:login.php?error=".$msg);
	die;	
}

?>