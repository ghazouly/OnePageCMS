<?php session_start();

session_decode(); 
header('location: login.php');
die;
 ?>