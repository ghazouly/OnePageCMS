<?php 
include 'header.php';


include_once 'config/Dbconfig.php';
include_once('php_library/Mysql.php');
$conn = new Mysql();

$conn -> dbConnect();
$res = $conn -> selectWhere('works', 'id', '=', $_GET['id'], 'int');

$work= mysql_fetch_array($res);

extract($work);

$conn->dbDisconnect();


?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Works</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>

    <?php 

    if(isset($_GET['msg']))
    {
        if($_GET['msg'] == 'empty') { echo '<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        please enter all fields data
        </div>' ; }
    } ?>
    <!-- /.row -->
    <div class="row">
       <div class="panel panel-default">
        <div class="panel-heading">
            Add New Sample
        </div>
        <div class="panel-body">
            <div class="row">
                <form action="updatework.php?id=<?php  echo $_GET['id']; ?>" method="post" enctype="multipart/form-data"  >
                    <div class="col-md-12">
                        <h4>current image is :</h4>
                        <img src="<?php echo $img;  ?>" alt="">
                        <div class="form-group">
                            <label>choose another image</label>
                            <input type="file" name="file">
                        </div>
                        <label>link (optional)</label>
                        <div class="form-group input-group" >

                            <span class="input-group-addon"><i class="fa fa-link"></i></span>
                            <input type="text" name="link" value="<?php echo $link; ?>" class="form-control" placeholder="Username">
                        </div>
                        <p class="form-control-static"><h4> example: http://www.exmaple.com</h4></p>
                        <div class="col-md-12">
                            <div class="col-md-6">
                                <h2>Arabic content</h2>
                                <div class="form-group">
                                    <label>title</label>
                                    <input class="form-control"  value="<?php echo $ar_title; ?>" placeholder="Enter text" name="ar_title">
                                </div>
                                <div class="form-group">
                                    <label>content</label>
                                    <textarea class="form-control" placeholder="Enter text" name="ar_content" cols="30" rows="10"><?php echo $ar_content; ?></textarea>
                                    
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h2>English content</h2>
                                <div class="form-group">
                                    <label>title</label>
                                    <input class="form-control" placeholder="Enter text" value="<?php echo $en_title; ?>" name="en_title">
                                </div>
                                <div class="form-group">
                                    <label>content</label>
                                    <textarea class="form-control" placeholder="Enter text" name="en_content" cols="30" rows="10"><?php echo $en_content; ?></textarea>
                                </div>
                            </div>
                            <input type="submit" class="btn btn-primary " value="update sample" name="submit">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /.row -->
</div>
<!-- /#page-wrapper -->
<?php 

include 'footer.php';

?>
