<?php 
session_start();
include_once 'config/Dbconfig.php';
include('php_library/Mysql.php');
$conn=new Mysql();
if($_GET['id']){
		
		
		$conn->dbConnect();
		$where="WHERE id=".$_GET['id'];
		$result=$conn -> dbRowDelete('skills', $where);
		$conn->dbDisconnect();
		if($result)
		{
			$msg='successde';
		}
		else
		{
			$msg='failde';
			
		}
		header("location:skills.php?msg=".$msg."");
		die;
	
}else{
	$msg='fail';
	header("location:skills.php?msg=".$msg."");
	header("content-type: text/html");
	die;
}
?>