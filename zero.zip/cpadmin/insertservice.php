<?php
session_start();
include_once 'config/Dbconfig.php';
include_once 'php_library/Mysql.php';

if (isset($_POST['submit']) && !empty($_POST['en_title']) && !empty($_POST['en_content']) ) 
{
	

	$conn = new Mysql();
	$conn -> dbConnect();
	 // var_dump($conn); die();

	$ar_title = $_POST['ar_title'];
	$ar_title = stripslashes($ar_title);
	$ar_title = mysql_real_escape_string($ar_title);

	$ar_content = $_POST['ar_content'];
	$ar_content = stripcslashes($ar_content);
	$ar_content = mysql_real_escape_string($ar_content);

	$en_title = $_POST['en_title'];
	$en_title = stripslashes($en_title);
	$en_title = mysql_real_escape_string($en_title);

	$en_content = $_POST['en_content'];
	$en_content = stripslashes($en_content);
	$en_content = mysql_real_escape_string($en_content);

	$icon = $_POST['icon'];
	$icon = stripslashes($icon);
	$icon = mysql_real_escape_string($icon);

	
	
	
	$form_data = array(
		'ar_title' => $ar_title,
		'ar_content' => $ar_content,
		'en_title' => $en_title,
		'en_content' => $en_content,
		'icon' => $icon 

		);
	$result=$conn->dbRowInsert('services', $form_data);
	$conn->dbDisconnect();
	
	
	if($result){
		header("location:services.php?msg=successins");
	}
	else
	{

		header("location:services.php?msg=failins");
	}

}
else 
{
	header("location:services.php?msg=empty");
}
?>