<?php
session_start();
include_once 'config/Dbconfig.php';
include ('php_library/Mysql.php');



if (isset($_POST['submit'])) {

	$conn = new Mysql();
	$conn -> dbConnect();

$id = $_GET['id'];
	$ar_name = $_POST['ar_name'];
	$ar_name = stripcslashes($ar_name);
	$ar_name = mysql_real_escape_string($ar_name);

	$en_name = $_POST['en_name'];
	$en_name = stripslashes($en_name);
	$en_name = mysql_real_escape_string($en_name);


	$per = $_POST['per'];
	$per = stripslashes($per);
	$per = mysql_real_escape_string($per);
	
	
	
	
	$form_data = array(

		'ar_name' => $ar_name,
		'en_name' => $en_name,
		'per' => $per,
		);
	$where = "WHERE id=$id";

	$result = $conn -> dbRowUpdate('skills', $form_data, $where);

	$conn -> dbDisconnect();

	if ($result) {
		header("location:skills.php?msg=successup");
	} else {

		header("location:skills.php?msg=failiup");
	}

} else {
	header("location:skills.php");
}
?>