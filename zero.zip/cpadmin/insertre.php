<?php
session_start();

include_once 'config/Dbconfig.php';
include_once 'php_library/Mysql.php';
include_once 'php_library/SimpleImage.php';

function generateRandomString($length = 10) {
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$charactersLength = strlen($characters);
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
		$randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	return $randomString;
}

if (isset($_POST['submit']) && isset($_FILES['file']) && !empty($_FILES['file']['name'])) 
{
	

	$conn = new Mysql();
	$conn -> dbConnect();
	$ar_content = $_POST['ar_content'];
	$ar_content = stripcslashes($ar_content);
	$ar_content = mysql_real_escape_string($ar_content);

	$en_content = $_POST['en_content'];
	$en_content = stripslashes($en_content);
	$en_content = mysql_real_escape_string($en_content);

	$ar_name = $_POST['ar_name'];
	$ar_name = stripslashes($ar_name);
	$ar_name = mysql_real_escape_string($ar_name);

	
	$en_name = $_POST['en_name'];
	$en_name = stripslashes($en_name);
	$en_name = mysql_real_escape_string($en_name);
	$image = $_FILES['file']['name'];
	$ex = explode('.', $image);
	$ex = end($ex);
	$new_name = generateRandomString(12) . '.' .$ex;
	
	
	$folder = "../clients/";
		// image checking if exist or the input field is not empty
	if($image) {
			// creating a filename
		$filename = $folder . $new_name;
		
			// uploading image file to specified folder
		$copied = copy($_FILES['file']['tmp_name'], $filename);
		$img = new SimpleImage();
		$img->load($filename);
		$img->resize(145,137);
		if (file_exists($filename)){
			unlink($filename) or die("Failed to delete the image");}
			$img->save($filename);
		}


		$form_data = array(

			'en_content' => $en_content,				
			'en_name' => $en_name,				
			'img' => $new_name
			);
		$result=$conn->dbRowInsert('ppl', $form_data);
		$conn->dbDisconnect();


		if($result){
			header("location:clients.php?msg=successins");
		}
		else
		{
			
			header("location:clients.php?msg=failins");
		}
	}
	else 
	{
		header("location:addreview.php?msg=empty");
	}
	?>