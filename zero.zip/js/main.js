/*global $ , jquery , alert*/
$(document).ready(function ()
{
    $("html").niceScroll();
    $('.carousel').carousel({
      interval: 3000
    })
    
    $(".gear-check").click(function (){
        $(".color-option").fadeToggle();
    });
    
    var colorLi = $(".color-option ul li");
    
    colorLi
    .eq(0).css("backgroundColor","#e41b17").end()
    .eq(1).css("backgroundColor","#f1c40f").end()
    .eq(2).css("backgroundColor","#9b59b6").end()
    .eq(3).css("backgroundColor","#3498db").end()
    .eq(4).css("backgroundColor","#000000");
    
    colorLi.click(function (){
        //console.log($(this).attr("data.value"))
        $("link[href*='theme']").attr("href",$(this).attr("data.value"));
    });
    
    var scrollBtn = $(".scroll-top");
    $(window).scroll(function (){
        //console.log($(this).scrollTop());
        /*if($(this).scrollTop() >= 1000){
            scrollBtn.show();
        }
        else{
            scrollBtn.hide();
        }*/
        $(this).scrollTop() >= 1000 ? scrollBtn.show() : scrollBtn.hide();  
    });
    
    scrollBtn.click(function (){
           $("html,body").animate({scrollTop : 0}, 600)
        });
        $('.smoothscroll').on('click',function (e) {
	    e.preventDefault();
	    var target = this.hash,
	    $target = $(target);
	    $('html, body').stop().animate({
	        'scrollTop': $target.offset().top
	    }, 800, 'swing', function () {
	        window.location.hash = target;
	    });
	});
});

$(window).load(function (){
    
    $(".loading-overlay .spinner").fadeOut(2000,
    function ()
    {      $("body").css("overflow","auto"); 
        $(this).parent().fadeOut(2000,
        function (){
            $(this).remove();
        });      
    }); 
    
});

