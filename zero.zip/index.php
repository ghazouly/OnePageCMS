<?php
  // error_reporting(0);
include_once 'cpadmin/config/Dbconfig.php';
include_once 'cpadmin/php_library/Mysql.php';

$conn = new Mysql();
$conn -> dbConnect();


?>

<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="content-type" content="text/html" />
    <meta name="author" content="gencyolcu" />
    
    <link href="css/hover.css" rel="stylesheet" media="all">

    
    <link href="css/bootstrap.css" rel="stylesheet"/>
    <link href="css/font-awesome.min.css" rel="stylesheet"/>
    <link href="css/animate.css" rel="stylesheet"/>
    <link href="css/style.css" rel="stylesheet"/>
    <link href="css/media.css" rel="stylesheet"/>
    
    
    <link rel="shortcut icon" href="img/icon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
    
    <script src="Gruntfile.js" type="text/javascript"></script>
    <title>Untitled 1</title>
</head>

<body>

    <div id="sec" class="navbar-fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="col-xs-2">
                        <a class="smoothscroll" href="#sec1"><img src="img/final.png" width="150"/></a>
                    </div>


                    <div class="col-xs-7">
                        <nav class="navbar navbar-default">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>

                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                          <ul class="nav navbar-nav">
                            <li><a class="smoothscroll hvr-sweep-to-right" href="#sec1" href="#">Home <span class="sr-only">(current)</span></a></li>
                            <li><a class="smoothscroll hvr-sweep-to-right" href="#sec2" href="#">About</a></li>
                            <li><a class="smoothscroll hvr-sweep-to-right" href="#sec3" href="#">Services</a></li>
                            <li><a class="smoothscroll hvr-sweep-to-right" href="#sec4" href="#">Solutions</a></li>
                            <li><a class="smoothscroll hvr-sweep-to-right" href="#sec5" href="#">Clients</a></li>
                            <li><a class="smoothscroll hvr-sweep-to-right" href="#sec6" href="#">Career</a></li>
                            <li><a class="smoothscroll hvr-sweep-to-right" href="#sec7" href="#">Contacts</a></li>
                        </ul>
                    </div><!-- /.navbar-collapse -->
                </nav>
            </div>
            <div class="col-xs-3 social_link">
                <a href="#"><i class="fa fa-behance-square"></i></a>
                <a href="#"><i class="fa fa-tumblr-square"></i></a>
                <a href="#"><i class="fa fa-pinterest-square"></i></a>
                <a href="#"><i class="fa fa-linkedin-square"></i></a>
                <a href="#"><i class="fa fa-instagram"></i></a>
                <a href="#"><i class="fa fa-youtube-square"></i></a>
                <a href="#"><i class="fa fa-google-plus-square"></i></a>
                <a href="#"><i class="fa fa-twitter-square"></i></a>
                <a href="#"><i class="fa fa-facebook-square"></i></a>
            </div>
            
        </div></div></div>
    </div>

    <section id="sec1">
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
          <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
        </ol>

        <!-- Wrapper for slides -->

        <div class="carousel-inner">

            <?php 
            $slides = $conn -> selectAll('slider');
            $i = 0;

            while ($slide = mysql_fetch_assoc($slides)) {
                extract($slide);
                if($i==0) {
                    echo '
                    <div class="item active">
                    <img src="uploaded/'.$img.'" width="100%" alt="pic 1">
                    <div class="carousel-caption wow fadeInRight" data-wow-duration="2s"  data-wow-offset="0">
                    <span class="title">'.$en_title.'</span>
                    <p>'.$en_sub_title.'</p>
                    </div>
                    </div>
                    ';
                }
                else {
                    echo '
                    <div class="item">
                    <img src="uploaded/'.$img.'" width="100%" alt="pic 1">
                    <div class="carousel-caption wow fadeInRight" data-wow-duration="2s"  data-wow-offset="0">
                    <span class="title">'.$en_title.'</span>
                    <p>'.$en_sub_title.'</p>
                    </div>
                    </div>
                    ';
                }


                $i++;
            }


            ?>

        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
        <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
    </div>
</section>

<section id="sec2">
    <div class="container">
        <div class="row">
           
<?php 
            $slides = $conn -> selectAll('info');

            if ($slide = mysql_fetch_assoc($slides)) {
            extract($slide);
            echo '
            <div class="col-md-5 col-xs-12 wow rotateInDownLeft" data-wow-duration="2s"  data-wow-offset="500">
                <img src="info/'.$img.'" class="img-responsive"/>
            </div>
            <div class="about col-md-7 col-xs-12 wow fadeInRightBig" data-wow-duration="2s">
                <span>'.$en_title.'</span>
                <p>'.$en_sub_title.'</p>
                </div>
            </div>';
            }
?>

        </div>
    </section>

    <section id="sec3">
        <div class="bg1">
            <div class="trans1">
                <div class="container">
                    <div class="row">
                        <div class="services">


                        <?php 
                            $slides = $conn -> selectAll('services');

                            while ($slide = mysql_fetch_assoc($slides)) {
                            extract($slide);
                            echo '
                            <div class="col-md-4 col-xs-12 wow fadeInDown" data-wow-duration="2s"  data-wow-offset="200" data-wow-delay="0.5s" >
                                <h3><i class="fa fa-cogs"></i>'.$en_title.'</h3>
                                <p>'.$en_content.'</p>
                            </div>
                            ';
                            $i++;
                            }
                        ?>

                        </div>
                    </div>
                </div>
            </div></div>
        </section>

        <section id="sec4">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12" >
                        <div role="tabpanel">

                          <!-- Nav tabs -->
                          <ul class="nav nav-tabs wow fadeInLeft" data-wow-duration="2s"  data-wow-offset="100" data-wow-delay="0.5s" role="tablist">
                            <li role="presentation" class="active"><a href="#link1" aria-controls="home" role="tab" data-toggle="tab">Customized ERP</a></li>
                            <li role="presentation"><a href="#link2" aria-controls="profile" role="tab" data-toggle="tab">Mobile Apps</a></li>
                        </ul>

                        <!-- Tab panes -->
                        <div class="tab-content">
                            
                        <?php 
                        $slides = $conn -> selectAll('works');
                        $i = 0;

                        while ($slide = mysql_fetch_assoc($slides)) {
                            extract($slide);
                            if($i==0) {
                            echo '
                            <div role="tabpanel" class="tab-pane active" id="link1">
                                <div class="col-xs-12">
                                    <div class="txt1 col-md-8 col-xs-12 wow fadeInLeft" data-wow-duration="2s"  data-wow-offset="100" data-wow-delay="1.5s">
                                        <span>'.$en_title.'</span>
                                        <p>'.$en_content.'</p>
                                    </div>
                                    <div class="pic1 col-md-4 col-xs-12">
                                        <img src="solution/'.$img.'" class="img-responsive wow bounceIn" data-wow-duration="2s"  data-wow-offset="100" data-wow-delay="2.5s"/>
                                    </div>
                                </div>
                            </div> ';
                            }
                            else{
                            echo '
                            <div role="tabpanel" class="tab-pane active" id="link2">
                                <div class="col-xs-12">
                                    <div class="txt1 col-md-8 col-xs-12 wow fadeInLeft" data-wow-duration="2s"  data-wow-offset="100" data-wow-delay="1.5s">
                                        <span>'.$en_title.'</span>
                                        <p>'.$en_content.'</p>
                                    </div>
                                    <div class="pic1 col-md-4 col-xs-12">
                                        <img src="solution/'.$img.'" class="img-responsive wow bounceIn" data-wow-duration="2s"  data-wow-offset="100" data-wow-delay="2.5s"/>
                                    </div>
                                </div>
                            </div> ';
                            }
                            $i++;
                            }
                        ?>
                        </div>


                                </section>

                                <section id="sec5"class="clients">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xs-12" >
                                              
                                            <?php 
                                            $slides = $conn -> selectAll('ppl');
                                            $i = 0;

                                            while ($slide = mysql_fetch_assoc($slides)) {
                                                extract($slide);
                                                if($i==0) {
                                                echo '
                                            <div class="col-sm-6 col-md-3 wow bounceIn"  data-wow-duration="2s"  data-wow-offset="100" data-wow-delay="0.5s">
                                                <div class="thumbnail hvr-radial-out">
                                                  <img src="clients/'.$img.'" class="img-circle img-responsive"/>
                                                  <div class="caption">
                                                    <h3>'.$en_name.'</h3>
                                                    <p>'.$en_content.'</p>
                                                    </div>
                                                </div>
                                            </div>';
                                                }
                                                else{
                                               echo '
                                            <div class="col-sm-6 col-md-3 wow bounceIn" data-wow-duration="2s"  data-wow-offset="100" data-wow-delay="0.5s">
                                                <div class="thumbnail hvr-radial-out">
                                                  <img src="clients/'.$img.'" class="img-circle img-responsive"/>
                                                  <div class="caption">
                                                    <h3>'.$en_name.'</h3>
                                                    <p>'.$en_content.'</p>
                                                    </div>
                                                </div>
                                            </div>';
                                            }
                                            $i++;
                                        }

                                                ?>



                                        </div></div></div>
                                    </section>

                                    <section id="sec6" class="career">
                                        <div class="cv">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-md-6 col-xs-12">
                                                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                                          <div class="panel panel-default wow fadeInLeft" data-wow-duration="2s"  data-wow-offset="50" data-wow-delay="0.5s">
                                                              <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                                                <div class="panel-heading" role="tab" id="headingOne">
                                                                  <h4 class="panel-title">

                                                                      Senior ADF Developer

                                                                  </h4>
                                                              </div>
                                                          </a>
                                                          <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                                              <div class="panel-body">

                                                                  <p class="description">Description:</p>
                                                                  <span>Building web applications using JavaEE technologies with different frame works. Corporate in the analysis and design phase for the applications.</span>
                                                                  <p>Skills:</p>
                                                                  <span>
                                                                    · 4 years experience in developing web applications using JSF framework.
                                                                    · Leading skills and experience is highly appreciated.
                                                                    · Strong knowledge about Java EE technologies. JSP, servlets, EJB and webservices are a must.</span>
                                                                    <p>Responsibilities:</p>
                                                                    <span>
                                                                        · Developing web applications using JSF framework.
                                                                        · Ability to learn new frameworks and technologies.
                                                                    </span>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="panel panel-default wow fadeInLeft" data-wow-duration="2s"  data-wow-offset="50" data-wow-delay="1.0s">
                                                          <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                            <div class="panel-heading" role="tab" id="headingTwo">
                                                              <h4 class="panel-title">

                                                                  Senior Quality Engineer

                                                              </h4>
                                                          </div>
                                                      </a>
                                                      <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                          <div class="panel-body">
                                                              <p class="description">Description:</p>
                                                              <span>Building web applications using JavaEE technologies with different frame works. Corporate in the analysis and design phase for the applications.</span>
                                                              <p>Skills:</p>
                                                              <span>
                                                                · 4 years experience in developing web applications using JSF framework.
                                                                · Leading skills and experience is highly appreciated.
                                                                · Strong knowledge about Java EE technologies. JSP, servlets, EJB and webservices are a must.</span>
                                                                <p>Responsibilities:</p>
                                                                <span>
                                                                    · Developing web applications using JSF framework.
                                                                    · Ability to learn new frameworks and technologies.
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="panel panel-default wow fadeInLeft" data-wow-duration="2s"  data-wow-offset="50" data-wow-delay="1.5s">
                                                      <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                        <div class="panel-heading" role="tab" id="headingThree">
                                                          <h4 class="panel-title">

                                                              Senior Middle ware Adminstrator

                                                          </h4>
                                                      </div>
                                                  </a>
                                                  <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                      <div class="panel-body">
                                                        <p class="description">Description:</p>
                                                        <span>Building web applications using JavaEE technologies with different frame works. Corporate in the analysis and design phase for the applications.</span>
                                                        <p>Skills:</p>
                                                        <span>
                                                            · 4 years experience in developing web applications using JSF framework.
                                                            · Leading skills and experience is highly appreciated.
                                                            · Strong knowledge about Java EE technologies. JSP, servlets, EJB and webservices are a must.</span>
                                                            <p>Responsibilities:</p>
                                                            <span>
                                                                · Developing web applications using JSF framework.
                                                                · Ability to learn new frameworks and technologies.
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div></div>
                                            <div class="col-md-6 col-xs-12 form wow zoomIn" data-wow-duration="1s" data-wow-offset="20" data-wow-delay="2.5s">
                                                <form role="form">

                                                    <div class="form-group">
                                                        <input type="text" class="form-control input-lg" placeholder="Username *"/>
                                                    </div>

                                                    <div class="form-group">
                                                        <input type="text" class="form-control input-lg" placeholder="Job *"/>
                                                    </div>

                                                    <div class="form-group">
                                                        <h4>Birth Of Date</h4>
                                                        <select>
                                                            <option>Day</option>
                                                            <option>1</option>
                                                            <option>2</option>
                                                            <option>3</option>
                                                            <option>4</option>
                                                            <option>5</option>
                                                        </select>
                                                        <select>
                                                            <option>Month</option>
                                                            <option>1</option>
                                                            <option>2</option>
                                                            <option>3</option>
                                                            <option>4</option>
                                                            <option>5</option>
                                                        </select>
                                                        <select>
                                                            <option>Year</option>
                                                            <option>1994</option>
                                                            <option>1993</option>
                                                            <option>1992</option>
                                                            <option>1991</option>
                                                            <option>1990</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <h4>Work Type</h4>
                                                        <select>
                                                            <option>work type</option>
                                                            <option>Full-Time</option>
                                                            <option>Part-Time</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <h4>Upload you CV</h4>
                                                        <input type="file"/>
                                                    </div>
                                                    <div class="form-group">
                                                        <input type="text" class="form-control input-lg" placeholder="Online CV / Portfolio link
                                                        "/>
                                                    </div>
                                                    <button type="button" class="btn btn-primary btn-lg btn-block">Send</button>
                                                </form>
                                            </div>
                                        </div></div></div>
                                    </section>

                                    <section id="sec7" class="contact-us text-center">
                                        <div class="fields">
                                            <div class="container">
                                                <div class="row">

                                                    <i class="fa fa-headphones fa-5x"></i>
                                                    <h1 class="wow bounceIn" data-wow-duration="2s"  data-wow-offset="50">Tell Us What You Feel</h1>
                                                    <p class="lead wow bounceIn" data-wow-duration="2s"  data-wow-offset="50">Feel Free To Contact Us Any Time</p>



                                                    <form role="form" name="send" action="sendmail.php" method="POST">
                                                        <div class="col-md-6 wow bounceInLeft" data-wow-duration="2s"  data-wow-offset="50">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control input-lg" name="name" placeholder="Username"/>
                                                            </div>

                                                            <div class="form-group">
                                                                <input type="text" class="form-control input-lg" name="email" placeholder="E-mail"/>
                                                            </div>

                                                            <div class="form-group">
                                                                <input type="text" class="form-control input-lg" name="phone" placeholder="Phone"/>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-6 wow bounceInRight" data-wow-duration="2s"  data-wow-offset="200">
                                                            <div class="form-group">
                                                                <textarea class="form-control input-lg" name="msg" placeholder="Your Message"></textarea>
                                                            </div>
                                                            <button type="button" class="btn btn-primary btn-lg btn-block">Contact Us</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </section>

                                    <footer>

                                      <div class="row">



                                         <ul class="list-unstyled">
                                            <li class="active"><a class="smoothscroll" href="#sec1" href="#">Home <span class="sr-only">(current)</span></a></li>
                                            <li><a class="smoothscroll" href="#sec2" href="#">About</a></li>
                                            <li><a class="smoothscroll" href="#sec3" href="#">Services</a></li>
                                            <li><a class="smoothscroll" href="#sec4" href="#">Solutions</a></li>
                                            <li><a class="smoothscroll" href="#sec5" href="#">Clients</a></li>
                                            <li><a class="smoothscroll" href="#sec6" href="#">Career</a></li>
                                            <li><a class="smoothscroll" href="#sec7" href="#">Contacts</a></li>
                                        </ul>
                                        <div class="twelve columns">
                                            <div class="col-xs-12 social_link">
                                                <a href="#"><i class="fa fa-behance-square"></i></a>
                                                <a href="#"><i class="fa fa-tumblr-square"></i></a>
                                                <a href="#"><i class="fa fa-pinterest-square"></i></a>
                                                <a href="#"><i class="fa fa-linkedin-square"></i></a>
                                                <a href="#"><i class="fa fa-instagram"></i></a>
                                                <a href="#"><i class="fa fa-youtube-square"></i></a>
                                                <a href="#"><i class="fa fa-google-plus-square"></i></a>
                                                <a href="#"><i class="fa fa-twitter-square"></i></a>
                                                <a href="#"><i class="fa fa-facebook-square"></i></a>
                                            </div>

                                            <ul class="copyright">
                                               <li>&copy; Copyright 2015 Zero</li><br />
                                               <li>Design by <a title="Hesham Ashraf" href="https://www.facebook.com/hesham7.ashraf">Hesham Ashraf</a></li>
                                               <li>Developed by <a title="Magued Fathey" href="https://www.facebook.com/maguedfathey">Magued Fathey</a></li>   
                                           </ul>

                                       </div>

                                       <div id="go-top"><a class="smoothscroll" title="Back to Top" href="#sec1"><i class="fa fa-chevron-up"></i></a></div>

                                   </div>

                               </footer>
                               <!-- Start Script File -->
                               <script src="js/jquery.js" type="text/javascript"></script>
                               <script src="js/bootstrap.js" type="text/javascript"></script>
                               <script src="js/jquery.nicescroll.min.js" type="text/javascript"></script>
                               <script src="js/main.js" type="text/javascript"></script>
                               <script src="js/wow.min.js" type="text/javascript"></script>
                               <script>
                               new WOW().init();
                               </script>
                           </body>
                           </html>