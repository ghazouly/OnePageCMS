<?php
    //Check the "name" of the field for the presence of the filling
if(!empty($_POST['name'])) {
    $name = trim($_POST['name']);
    if(!empty($_POST['phone'])) {
	    $phone = trim($_POST['phone']);
    	if(!empty($_POST['email'])) {
    		$email = trim($_POST['email']);
    		if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
    			if(!empty($_POST['msg']))
    			{
    				$message = stripslashes(trim($_POST['msg']));
    				$subject = 'new message';
                    $emailTo = 'ahmedsamigeek@gmail.com'; //Put your own email address here
                    $body = "Name: $name \n\nEmail: $email \n\nSubject: new message \n\nmessage:\n $message ";
                    $headers = "From: ".$name." ,".$phone." <".$email.">\r\nReply-To: ".$email."";
                    $headers = 'From: www.yoursite.com <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email;

                    $sent = mail($emailTo, $subject, $body, $headers);
                    if ($sent) {
                    	echo "done"; 
                    } else {
                    	echo "again";
                    }
                }
                else {
            	echo "msg";  

            }
        }
        else {
        	echo "emailiv";  

        }
    }
    else {
    	echo "email";  

    }
} else {
	echo "name";  
}















